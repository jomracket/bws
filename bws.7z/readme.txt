bws -- a WonderSwan and WonderSwan Color emulator

Version => 1.0.0
Author  => byuu
Website => http://byuu.org

Menu Access
===========
The main menu can be accessed by right-clicking anywhere inside the content area
of the program's main window.

Load Games
==========
Games can be loaded from the main menu. They can be in .zip, .ws or .wsc format.

Save States
===========
Up to five save states slots are supported from the main menu.


Key Configuration
=================
Use the rotate key to change the orientation of the display.
bws will automatically default to the preferred orientation of the loaded game.

Horizontal Orientation
----------------------
Y1     => Home
Y2     => Page Down
Y3     => End
Y4     => Delete
X1     => Up
X2     => Right
X3     => Down
X4     => Left
B      => Z
A      => X
Start  => Enter
Rotate => Apostrophe

Vertical Orientation
--------------------
Y1     => Left
Y2     => Up
Y3     => Right
Y4     => Down
X1     => Delete
X2     => Home
X3     => Page Down
X4     => End
B      => X
A      => Z
Start  => Enter
Rotate => Apostrophe
